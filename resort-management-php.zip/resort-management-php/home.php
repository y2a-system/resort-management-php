        <div class="welcome-content">
            <?php include("welcome.html") ?>
        </div>
