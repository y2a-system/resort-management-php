<div class="col-lg-12">
    <?php include("about_us.html") ?>
</div>
